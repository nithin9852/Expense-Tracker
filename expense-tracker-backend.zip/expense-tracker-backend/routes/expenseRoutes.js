const express = require("express");
const Expense = require("../models/Expense");
const auth = require("../middleware/authMiddleware");

const router = express.Router();


router.get("/", auth, async (req, res) => {
  const expenses = await Expense.find({ user: req.userId });
  res.json(expenses);
});


router.post("/", auth, async (req, res) => {
  const expense = new Expense({
    title: req.body.title,
    amount: req.body.amount,
    category: req.body.category,
    user: req.userId
  });

  const saved = await expense.save();
  res.json(saved);
});

module.exports = router;
