import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  PieChart, Pie, Cell,
  BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer,
  Legend, CartesianGrid
} from "recharts";
import "./ExpenseTracker.css";

const COLORS = ["#4f46e5", "#16a34a", "#dc2626", "#f59e0b", "#0ea5e9"];

export default function ExpenseTracker({ onLogout }) {
  const userEmail = localStorage.getItem("userEmail");

  const [expenses, setExpenses] = useState([]);
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("Food");
  const [filterCategory, setFilterCategory] = useState("All");
  const [hasLoaded, setHasLoaded] = useState(false);

  const inputRef = useRef(null);

  // 🔹 LOAD expenses FIRST (very important)
  useEffect(() => {
    if (!userEmail) return;

    const stored = JSON.parse(
      localStorage.getItem(`expenses_${userEmail}`)
    );

    setExpenses(stored || []);
    setHasLoaded(true);
  }, [userEmail]);

  useEffect(() => {
    if (!userEmail || !hasLoaded) return;

    localStorage.setItem(
      `expenses_${userEmail}`,
      JSON.stringify(expenses)
    );
  }, [expenses, userEmail, hasLoaded]);

  const addExpense = useCallback(() => {
    if (!title || !amount) return;

    setExpenses(prev => [
      ...prev,
      {
        id: Date.now(),
        title,
        amount: Number(amount),
        category,
        date: new Date().toISOString()
      }
    ]);

    setTitle("");
    setAmount("");
    inputRef.current.focus();
  }, [title, amount, category]);

  const deleteExpense = useCallback(id => {
    setExpenses(prev => prev.filter(e => e.id !== id));
  }, []);

  const filteredExpenses = useMemo(() => {
    return filterCategory === "All"
      ? expenses
      : expenses.filter(e => e.category === filterCategory);
  }, [expenses, filterCategory]);

  const totalExpense = useMemo(
    () => expenses.reduce((s, e) => s + e.amount, 0),
    [expenses]
  );

  const categoryData = useMemo(() => {
    const map = {};
    expenses.forEach(e => {
      map[e.category] = (map[e.category] || 0) + e.amount;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const monthlySummary = useMemo(() => {
    const map = {};
    expenses.forEach(e => {
      const month = new Date(e.date).toLocaleString("default", {
        month: "short",
        year: "numeric"
      });
      map[month] = (map[month] || 0) + e.amount;
    });
    return Object.entries(map).map(([month, total]) => ({ month, total }));
  }, [expenses]);

  return (
    <div className="container">
      <button className="logout-btn" onClick={onLogout}>Logout</button>

      <h1 className="title">Expense Tracker</h1>
      <h2 className="total">Total: ₹{totalExpense}</h2>

      {}
      <div className="form-grid">
        <input
          ref={inputRef}
          placeholder="Title"
          value={title}
          onChange={e => setTitle(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={e => setAmount(e.target.value)}
        />
        <select value={category} onChange={e => setCategory(e.target.value)}>
          <option>Food</option>
          <option>Travel</option>
          <option>Shopping</option>
          <option>Rent</option>
          <option>Other</option>
        </select>
        <button className="add-btn" onClick={addExpense}>Add</button>
      </div>

      {}
      <div className="filter">
        <label>Filter:</label>
        <select
          value={filterCategory}
          onChange={e => setFilterCategory(e.target.value)}
        >
          <option>All</option>
          <option>Food</option>
          <option>Travel</option>
          <option>Shopping</option>
          <option>Rent</option>
          <option>Other</option>
        </select>
      </div>

      {}
      <ul className="expense-list">
        {filteredExpenses.map(e => (
          <li key={e.id}>
            <span>{e.title} ({e.category})</span>
            <span>
              ₹{e.amount}
              <button
                className="delete-btn"
                onClick={() => deleteExpense(e.id)}
              >
                ✕
              </button>
            </span>
          </li>
        ))}
      </ul>

      {}
      <div className="charts">
        <div className="chart-box">
          <h3>Category-wise Expenses</h3>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                dataKey="value"
                nameKey="name"
                label
              >
                {categoryData.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-box">
          <h3>Monthly Summary</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlySummary}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="total" fill="#0ea5e9" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
