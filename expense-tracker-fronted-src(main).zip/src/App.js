import { useState, useEffect } from "react";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ExpenseTracker from "./components/ExpenseTracker";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsAuthenticated(!!token);
  }, []);

  const handleLogin = (token, email) => {
    localStorage.setItem("token", token);
    localStorage.setItem("userEmail", email.trim().toLowerCase());
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userEmail");
    setIsAuthenticated(false);
  };

  return (
    <>
      {!isAuthenticated ? (
        <div className="auth-wrapper">
          <Signup onLogin={handleLogin} />
          <Login onLogin={handleLogin} />
        </div>
      ) : (
        <ExpenseTracker onLogout={handleLogout} />
      )}
    </>
  );
}

export default App;
